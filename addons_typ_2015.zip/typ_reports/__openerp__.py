# -*- encoding: utf-8 -*-

{
    'name': 'Reportes RMl, Webkit',
    'version': '1',
    "author" : "Argil C.",
    "category" : "TyP",
    'description': """

    """,
    "website" : "http://www.argil.mx/",
    "license" : "AGPL-3",
    "depends" : ["account","report_webkit"],
    "init_xml" : [],
    "demo_xml" : [],
    "update_xml" : [

                "report/account_report.xml",
                "account_view.xml",
                    ],
    "installable" : True,
    "active" : False,
}
