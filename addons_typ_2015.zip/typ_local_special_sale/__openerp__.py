# -*- encoding: utf-8 -*-

{
    'name': 'TyP Venta Especial',
    'version': '1',
    "author" : "Argil C.",
    "category" : "TyP",
    'description': """

    

    """,
    "website" : "http://www.argil.mx/",
    "license" : "AGPL-3",
    "depends" : ["sale","purchase"],
    "init_xml" : [],
    "demo_xml" : [],
    "update_xml" : [
        "sale_view.xml",
        "purchase_view.xml",
                    ],
    "installable" : True,
    "active" : False,
}
